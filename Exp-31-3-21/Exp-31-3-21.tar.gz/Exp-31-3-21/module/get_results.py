#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
# se ejecuta al final del file .sh
# en la carpeta results, en la carpeta del experimento
# toma cada csv metric y genera uno solo con toda la información
# borra archivos metric

cwd = os.getcwd()
cwd = cwd + "/results/"
#print(cwd)
if os.path.exists(cwd):
	
	lstFiles = []
	
	lstDir = os.walk(cwd)
	 
	for root, dirs, files in lstDir:
		for fichero in files:
			(nombreFichero, extension) = os.path.splitext(fichero)
			if(extension == ".txt"):
				lstFiles.append(cwd+nombreFichero+extension)
	#print(lstFiles)

	name = cwd+"results.csv"
	file_to_save = open(name, "a+")
	
	file_to_save.write("id number_agents alternatives_number maximum_number_practical_arguments maximum_number_epistemic_arguments maximum_attacks_density_value N step resource_boundness_density num_agents_R num_agents_RI metric_d std_metric_d res_boundeness time_neg_mean time_neg_std FP_mean FP_std FN_mean FN_std TP_mean TP_std TN_mean TN_std bullshit_mean bullshit_std gwc_mean gwc_std lwc_mean lwc_std\n")
	
	for filename in lstFiles:
		#copio contenido y lo pego en results (salto primera linea de titulo)
		file_new = open(filename, "r")
		content = file_new.read()
		file_new.close()
		for line in content:
			file_to_save.write(line)
		os.remove(filename)
	file_to_save.close()
	
	

else:
	print("None")
